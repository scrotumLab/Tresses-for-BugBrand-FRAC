PLEASE do not put or add any marking for prototype manufacturing on soldermask or silkscreen!!! 
Because these boards will be shown to a customer and will be used as display, frontpanels to show a customer how his product will look like once we decided it is OK for manufacturing with 3.2mm board.
THANK YOU!